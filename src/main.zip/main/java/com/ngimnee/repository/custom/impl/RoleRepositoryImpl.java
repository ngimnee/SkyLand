package com.ngimnee.repository.custom.impl;

import com.ngimnee.repository.custom.RoleRepositoryCustom;
import org.springframework.stereotype.Repository;

@Repository
public class RoleRepositoryImpl implements RoleRepositoryCustom {

}