package com.ngimnee.repository.custom.impl;

import com.ngimnee.repository.custom.TransactionRepositoryCustom;
import org.springframework.stereotype.Repository;

@Repository
public class TransactionRepositoryImpl implements TransactionRepositoryCustom {
}
