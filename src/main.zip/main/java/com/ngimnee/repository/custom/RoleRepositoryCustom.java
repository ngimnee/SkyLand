package com.ngimnee.repository.custom;

public interface RoleRepositoryCustom {
}
