package com.ngimnee.api.web;

import org.springframework.web.bind.annotation.RestController;

@RestController(value = "newAPIOfWeb")
public class NewAPI {
	
	
}
