package com.ngimnee.exception;

public class MyException extends Exception {
    public MyException(String message) {
        super(message);
    }
}
